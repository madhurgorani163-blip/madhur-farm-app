import 'package:flutter/material.dart';

void main() => runApp(const MadhurFarmApp());

const farmGreen = Color(0xFF247A4B);
const ink = Color(0xFF18352A);

class MadhurFarmApp extends StatelessWidget {
  const MadhurFarmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MADHUR FARM',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: farmGreen, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F8F5),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F8F5), foregroundColor: ink),
        cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      ),
      home: const FarmShell(),
    );
  }
}

class FarmShell extends StatefulWidget {
  const FarmShell({super.key});
  @override
  State<FarmShell> createState() => _FarmShellState();
}

class _FarmShellState extends State<FarmShell> {
  int selected = 0;
  // Initial profile supplied by the farm owner. Financial and stock records
  // start empty so the app never presents demonstration figures as real data.
  final crops = <CropRecord>[
    CropRecord('Pomegranate (Anar)', 'Main orchard', 'Established orchard', '5 acres'),
  ];
  final transactions = <FarmTransaction>[];
  final stock = <StockItem>[];

  void addCrop() async {
    final result = await showDialog<CropRecord>(context: context, builder: (_) => const CropDialog());
    if (result != null) setState(() => crops.add(result));
  }

  void addTransaction() async {
    final result = await showDialog<FarmTransaction>(context: context, builder: (_) => const TransactionDialog());
    if (result != null) setState(() => transactions.insert(0, result));
  }

  void addStock() async {
    final result = await showDialog<StockItem>(context: context, builder: (_) => const StockDialog());
    if (result != null) setState(() => stock.add(result));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(crops: crops, transactions: transactions, stock: stock, onAddCrop: addCrop, onAddTransaction: addTransaction, onAddStock: addStock, onNavigate: (i) => setState(() => selected = i)),
      CropsPage(crops: crops, onAdd: addCrop),
      FinancePage(transactions: transactions, onAdd: addTransaction),
      WeatherPage(),
      InventoryPage(stock: stock, onAdd: addStock),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: farmGreen.withValues(alpha: .12), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.eco, color: farmGreen)), const SizedBox(width: 10), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('MADHUR FARM', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, letterSpacing: .5)), Text('Farm management', style: TextStyle(fontSize: 11, color: Colors.black54))])]),
        actions: [IconButton(tooltip: 'Family access', onPressed: () => showDialog<void>(context: context, builder: (_) => const FamilyAccessDialog()), icon: const Icon(Icons.family_restroom_outlined)), IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'MADHUR FARM', applicationVersion: '1.0.0', children: const [Text('A farm management app starter for Android and iOS.')]), icon: const Icon(Icons.info_outline))],
      ),
      body: SafeArea(child: IndexedStack(index: selected, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: selected, onDestinationSelected: (i) => setState(() => selected = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.grass_outlined), selectedIcon: Icon(Icons.grass), label: 'Crops'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Finance'),
        NavigationDestination(icon: Icon(Icons.cloud_outlined), selectedIcon: Icon(Icons.cloud), label: 'Weather'),
        NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Stock'),
      ]),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.crops, required this.transactions, required this.stock, required this.onAddCrop, required this.onAddTransaction, required this.onAddStock, required this.onNavigate});
  final List<CropRecord> crops; final List<FarmTransaction> transactions; final List<StockItem> stock;
  final VoidCallback onAddCrop, onAddTransaction, onAddStock; final ValueChanged<int> onNavigate;
  @override
  Widget build(BuildContext context) {
    final income = transactions.where((e) => e.type == 'Income').fold<double>(0, (a, b) => a + b.amount);
    final expense = transactions.where((e) => e.type == 'Expense').fold<double>(0, (a, b) => a + b.amount);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1F7045), Color(0xFF3B9B65)]), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('WELCOME TO YOUR FARM', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)), SizedBox(height: 8), Text('Grow better.\nManage smarter.', style: TextStyle(color: Colors.white, fontSize: 27, height: 1.15, fontWeight: FontWeight.w800)), SizedBox(height: 12), Row(children: [Icon(Icons.location_on_outlined, color: Colors.white70, size: 16), SizedBox(width: 4), Text('Pantiya • Anjar • Kutch, Gujarat', style: TextStyle(color: Colors.white70))])])),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('YOUR ORCHARD', style: TextStyle(fontSize: 11, color: Colors.black54, fontWeight: FontWeight.w800, letterSpacing: .8)),
        const SizedBox(height: 8),
        const Row(children: [Icon(Icons.park_outlined, color: farmGreen, size: 25), SizedBox(width: 9), Expanded(child: Text('Pomegranate is your primary crop', style: TextStyle(fontWeight: FontWeight.w800)))]),
        const SizedBox(height: 8),
        const Text('5 acres total farm area  •  500–1,000 pomegranate trees', style: TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 4),
        const Text('Seasonal crops can be added whenever you plant them.', style: TextStyle(color: Colors.black54, fontSize: 12)),
      ]))),
      const SizedBox(height: 18), const SectionHeading('Farm overview'),
      GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.65, children: [MetricCard(icon: Icons.grass, label: 'Active crops', value: '${crops.length}', tint: const Color(0xFFE5F3E9)), MetricCard(icon: Icons.account_balance_wallet, label: 'Net balance', value: '₹${(income-expense).toStringAsFixed(0)}', tint: const Color(0xFFE8F0FA)), MetricCard(icon: Icons.trending_up, label: 'Total income', value: '₹${income.toStringAsFixed(0)}', tint: const Color(0xFFE5F3E9)), MetricCard(icon: Icons.inventory_2, label: 'Stock entries', value: '${stock.length}', tint: const Color(0xFFFFF1DC))]),
      const SizedBox(height: 20), const SectionHeading('Quick actions'), const SizedBox(height: 10),
      Row(children: [QuickAction(icon: Icons.add, label: 'Add crop', onTap: onAddCrop), const SizedBox(width: 10), QuickAction(icon: Icons.currency_rupee, label: 'Add entry', onTap: onAddTransaction), const SizedBox(width: 10), QuickAction(icon: Icons.inventory, label: 'Add stock', onTap: onAddStock)]),
      const SizedBox(height: 20), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const SectionHeading('Your crops'), TextButton(onPressed: () => onNavigate(1), child: const Text('View all'))]),
      ...crops.take(3).map((c) => CropTile(crop: c)),
      const SizedBox(height: 12), const SectionHeading('Weather'), const SizedBox(height: 8),
      Card(child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFE8F0FA), child: Icon(Icons.cloud_outlined, color: farmGreen)), title: const Text('Weather connection pending', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Connect a weather service to see local forecasts.'), trailing: const Icon(Icons.chevron_right), onTap: () => onNavigate(3))),
    ]);
  }
}

class CropsPage extends StatelessWidget { const CropsPage({super.key, required this.crops, required this.onAdd}); final List<CropRecord> crops; final VoidCallback onAdd;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [PageTitle('Crop management', 'Track fields, crop stages and harvests', action: IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle, color: farmGreen, size: 30))), const SizedBox(height: 12), ...crops.map((c) => CropTile(crop: c)), if (crops.isEmpty) const EmptyState('No crops added yet', 'Use + to add your first crop.')]); }

class FinancePage extends StatelessWidget { const FinancePage({super.key, required this.transactions, required this.onAdd}); final List<FarmTransaction> transactions; final VoidCallback onAdd;
  @override Widget build(BuildContext context) { final income = transactions.where((e)=>e.type=='Income').fold<double>(0,(a,b)=>a+b.amount); final expense=transactions.where((e)=>e.type=='Expense').fold<double>(0,(a,b)=>a+b.amount); return ListView(padding: const EdgeInsets.all(16), children: [PageTitle('Expenses & income', 'Keep track of your farm finances', action: IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle, color: farmGreen, size: 30))), const SizedBox(height: 12), Row(children: [Expanded(child: MetricCard(icon: Icons.south_west, label: 'Income', value: '₹${income.toStringAsFixed(0)}', tint: const Color(0xFFE5F3E9))), const SizedBox(width: 10), Expanded(child: MetricCard(icon: Icons.north_east, label: 'Expenses', value: '₹${expense.toStringAsFixed(0)}', tint: const Color(0xFFFFEAE7)))]), const SizedBox(height: 18), const SectionHeading('Recent transactions'), const SizedBox(height: 8), ...transactions.map((t) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: t.type=='Income'?const Color(0xFFE5F3E9):const Color(0xFFFFEAE7), child: Icon(t.type=='Income'?Icons.south_west:Icons.north_east, color: t.type=='Income'?farmGreen:Colors.redAccent)), title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('${t.type} • ${t.date.day}/${t.date.month}/${t.date.year}'), trailing: Text('${t.type=='Income'?'+':'−'}₹${t.amount.toStringAsFixed(0)}', style: TextStyle(fontWeight: FontWeight.w800, color: t.type=='Income'?farmGreen:Colors.redAccent))))), if(transactions.isEmpty) const EmptyState('No transactions yet','Add income or expense records.')]); } }

class WeatherPage extends StatelessWidget { const WeatherPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [const PageTitle('Weather updates', 'Local forecast for better farm decisions'), const SizedBox(height: 14), Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: const Column(children: [Icon(Icons.cloud_queue, size: 58, color: farmGreen), SizedBox(height: 12), Text('Weather service not connected', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), SizedBox(height: 8), Text('Live temperature, rainfall probability and forecasts for Pantiya, Anjar, Kutch will appear here after a weather provider is connected.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.45))])), const SizedBox(height: 12), const Card(child: ListTile(leading: Icon(Icons.location_on_outlined, color: farmGreen), title: Text('Pantiya, Anjar, Kutch'), subtitle: Text('Farm weather location is configured. Live weather service still needs to be connected.')))]); }

class InventoryPage extends StatelessWidget { const InventoryPage({super.key, required this.stock, required this.onAdd}); final List<StockItem> stock; final VoidCallback onAdd; @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [PageTitle('Sales & inventory', 'Monitor farm products and supplies', action: IconButton(onPressed: onAdd, icon: const Icon(Icons.add_circle, color: farmGreen, size: 30))), const SizedBox(height: 12), ...stock.map((s)=>Card(child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFE5F3E9), child: Icon(Icons.inventory_2_outlined, color: farmGreen)), title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(s.category), trailing: Text('${s.quantity} ${s.unit}', style: const TextStyle(fontWeight: FontWeight.w800, color: ink))))), if(stock.isEmpty) const EmptyState('Your inventory is empty','Add products or farm supplies.')]); }

class CropRecord { CropRecord(this.name, this.field, this.stage, this.area); final String name, field, stage, area; }
class FarmTransaction { FarmTransaction(this.title, this.type, this.amount, this.date); final String title, type; final double amount; final DateTime date; }
class StockItem { StockItem(this.name, this.category, this.quantity, this.unit); final String name, category, unit; final double quantity; }

class CropTile extends StatelessWidget { const CropTile({super.key, required this.crop}); final CropRecord crop; @override Widget build(BuildContext context) => Card(child: ListTile(leading: const CircleAvatar(backgroundColor: Color(0xFFE5F3E9), child: Icon(Icons.grass, color: farmGreen)), title: Text(crop.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${crop.field} • ${crop.area}'), trailing: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFE5F3E9), borderRadius: BorderRadius.circular(20)), child: Text(crop.stage, style: const TextStyle(color: farmGreen, fontSize: 11, fontWeight: FontWeight.w700))))); }
class SectionHeading extends StatelessWidget { const SectionHeading(this.text, {super.key}); final String text; @override Widget build(BuildContext context)=>Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: ink)); }
class PageTitle extends StatelessWidget { const PageTitle(this.title, this.subtitle, {super.key, this.action}); final String title, subtitle; final Widget? action; @override Widget build(BuildContext context)=>Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: ink)), const SizedBox(height:4), Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12))])), if(action!=null) action!]); }
class MetricCard extends StatelessWidget { const MetricCard({super.key, required this.icon, required this.label, required this.value, required this.tint}); final IconData icon; final String label, value; final Color tint; @override Widget build(BuildContext context)=>Card(child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment:CrossAxisAlignment.start, mainAxisAlignment:MainAxisAlignment.spaceBetween, children:[Container(padding: const EdgeInsets.all(7), decoration:BoxDecoration(color:tint, borderRadius:BorderRadius.circular(10)), child:Icon(icon, color:farmGreen, size:18)), Text(value, style: const TextStyle(fontSize:19, fontWeight:FontWeight.w800, color:ink)), Text(label, style: const TextStyle(fontSize:11, color:Colors.black54))]))); }
class QuickAction extends StatelessWidget { const QuickAction({super.key, required this.icon, required this.label, required this.onTap}); final IconData icon; final String label; final VoidCallback onTap; @override Widget build(BuildContext context)=>Expanded(child: InkWell(onTap:onTap, borderRadius:BorderRadius.circular(15), child: Container(padding: const EdgeInsets.symmetric(vertical:15, horizontal:5), decoration:BoxDecoration(color:Colors.white, borderRadius:BorderRadius.circular(15)), child:Column(children:[Icon(icon,color:farmGreen), const SizedBox(height:6), Text(label, style: const TextStyle(fontSize:11, fontWeight:FontWeight.w700))])))); }
class EmptyState extends StatelessWidget { const EmptyState(this.title,this.subtitle,{super.key}); final String title,subtitle; @override Widget build(BuildContext context)=>Padding(padding: const EdgeInsets.all(28), child:Column(children:[const Icon(Icons.inbox_outlined,size:40,color:Colors.black38), const SizedBox(height:8), Text(title,style:const TextStyle(fontWeight:FontWeight.w700)), Text(subtitle,style:const TextStyle(color:Colors.black54,fontSize:12))])); }

class CropDialog extends StatefulWidget { const CropDialog({super.key}); @override State<CropDialog> createState()=>_CropDialogState(); }
class _CropDialogState extends State<CropDialog>{ final name=TextEditingController(),field=TextEditingController(),area=TextEditingController(); String stage='Planned'; @override void dispose(){name.dispose();field.dispose();area.dispose();super.dispose();} @override Widget build(BuildContext context)=>AlertDialog(title:const Text('Add crop'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Crop name')),TextField(controller:field,decoration:const InputDecoration(labelText:'Field / location')),TextField(controller:area,decoration:const InputDecoration(labelText:'Area (e.g. 2 acres)')),DropdownButtonFormField<String>(value:stage,decoration:const InputDecoration(labelText:'Growth stage'),items:['Planned','Sowing','Growing','Ready to harvest','Harvested'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>stage=v??'Planned'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()=>name.text.trim().isEmpty?null:Navigator.pop(context,CropRecord(name.text.trim(),field.text.trim().isEmpty?'Unassigned field':field.text.trim(),stage,area.text.trim().isEmpty?'Not set':area.text.trim())),child:const Text('Save'))]);}
class TransactionDialog extends StatefulWidget { const TransactionDialog({super.key}); @override State<TransactionDialog> createState()=>_TransactionDialogState(); }
class _TransactionDialogState extends State<TransactionDialog>{final title=TextEditingController(),amount=TextEditingController();String type='Expense';@override void dispose(){title.dispose();amount.dispose();super.dispose();}@override Widget build(BuildContext context)=>AlertDialog(title:const Text('Add transaction'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Description')),TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (₹)')),DropdownButtonFormField<String>(value:type,items:['Expense','Income'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>type=v??'Expense'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()=>double.tryParse(amount.text)==null||title.text.trim().isEmpty?null:Navigator.pop(context,FarmTransaction(title.text.trim(),type,double.parse(amount.text),DateTime.now())),child:const Text('Save'))]);}
class StockDialog extends StatefulWidget { const StockDialog({super.key}); @override State<StockDialog> createState()=>_StockDialogState(); }
class _StockDialogState extends State<StockDialog>{final name=TextEditingController(),quantity=TextEditingController(),unit=TextEditingController(text:'kg');String category='Harvest stock';@override void dispose(){name.dispose();quantity.dispose();unit.dispose();super.dispose();}@override Widget build(BuildContext context)=>AlertDialog(title:const Text('Add inventory item'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Item name')),TextField(controller:quantity,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Quantity')),TextField(controller:unit,decoration:const InputDecoration(labelText:'Unit (kg, bags, litres)')),DropdownButtonFormField<String>(value:category,items:['Harvest stock','Farm supply','Seeds','Other'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>category=v??'Other'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()=>double.tryParse(quantity.text)==null||name.text.trim().isEmpty?null:Navigator.pop(context,StockItem(name.text.trim(),category,double.parse(quantity.text),unit.text.trim().isEmpty?'units':unit.text.trim())),child:const Text('Save'))]);}


class FamilyAccessDialog extends StatelessWidget {
  const FamilyAccessDialog({super.key});
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Row(children: [Icon(Icons.family_restroom, color: farmGreen), SizedBox(width: 9), Text('Family access')]),
    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('MADHUR FARM supports 1 owner and up to 2 family member accounts.', style: TextStyle(height: 1.4)),
      const SizedBox(height: 14),
      const ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(child: Icon(Icons.admin_panel_settings)), title: Text('Farm owner'), subtitle: Text('Administrator • Full access')),
      const ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(child: Icon(Icons.person_outline)), title: Text('Family member 1'), subtitle: Text('Available account slot')),
      const ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(child: Icon(Icons.person_outline)), title: Text('Family member 2'), subtitle: Text('Available account slot')),
      const SizedBox(height: 8),
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFEAF4ED), borderRadius: BorderRadius.circular(12)), child: const Text('Account invitations, sign-in and permission enforcement will be activated when cloud authentication is connected. This prototype does not yet create or secure family accounts.', style: TextStyle(fontSize: 12, height: 1.4))),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
  );
}
