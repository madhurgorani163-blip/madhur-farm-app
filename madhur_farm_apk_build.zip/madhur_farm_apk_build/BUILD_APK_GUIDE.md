# MADHUR FARM — Android APK build

This source package includes the Flutter app source and a GitHub Actions workflow that builds an APK in GitHub's hosted runner. The APK has not been compiled or tested locally in this package.


## Build with GitHub Actions

1. Create a new GitHub repository (for example `madhur-farm-app`).
2. Upload this package's files and folders to the repository root, keeping `.github/workflows/build-apk.yml` in place.
3. Open the repository's **Actions** tab.
4. Select **Build MADHUR FARM APK** and choose **Run workflow** (or push to the `main` branch).
5. Wait for the job to finish successfully.
6. Open the completed run and download the artifact named **madhur-farm-release-apk**.
7. Extract the artifact ZIP to find `app-release.apk`.


## Current app limitations

This app is a UI prototype. Entries are stored in memory and reset when the app restarts. Live weather, cloud sync, real authentication/family invitations, invoicing, backups, and production security are not implemented yet.
