# MADHUR FARM — Flutter starter

A cross-platform Flutter starter for an Android and iOS mixed-farm management app, preconfigured with the farm profile provided by its owner.

## Farm profile configured
- Farm: MADHUR FARM
- Location: Pantiya, Anjar, Kutch, Gujarat, India
- Total area: 5 acres
- Primary crop: Pomegranate (Anar / દાડમ)
- Pomegranate trees: approximately 500–1,000
- Other crops: seasonal crops can be added as needed

## Included in this build
- Material 3 green-and-white dashboard and bottom navigation
- Farm profile and orchard summary
- Pomegranate orchard preloaded as the primary crop (5 acres)
- Add and manage additional seasonal crop records
- Add income and expense records
- Add inventory and harvest stock records
- Weather screen labeled for Pantiya, Anjar, Kutch
- Family access overview configured for 1 owner + up to 2 family member accounts

## Important current limitations
This is an interactive UI prototype. Data is currently held in memory and resets when the app restarts. The finance and inventory lists intentionally start empty rather than showing made-up sample records. Weather, cloud sync, authentication/invitations, sales invoices, backups and production security are not connected yet. The family access dialog displays the configured account limit (1 owner + 2 family members); it does not yet create or authenticate accounts. The 500–1,000 tree count is shown as a farm profile estimate; individual tree-level records have not been entered.

## Run locally
Install Flutter (stable), then from this folder:

```bash
flutter pub get
flutter run
```

For Android, build with `flutter build apk --release`.
For iOS, build with `flutter build ios --release` on a Mac with Xcode installed.
